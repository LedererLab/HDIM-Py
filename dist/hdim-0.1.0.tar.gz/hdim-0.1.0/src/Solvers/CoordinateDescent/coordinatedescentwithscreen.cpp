//Explicit Instantiation of CDSR for Python Wrappers

#include "coordinatedescentwithscreen.hpp"

template class hdim::CoordinateDescentWithScreen<float>;
template class hdim::CoordinateDescentWithScreen<double>;
