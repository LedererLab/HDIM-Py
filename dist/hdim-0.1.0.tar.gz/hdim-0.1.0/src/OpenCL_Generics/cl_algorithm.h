#ifndef CLALGORITHM_H
#define CLALGORITHM_H

// C System-Headers
//
// C++ System headers
//
// Eigen Headers
//
// Boost Headers
//
// SPAMS Headers
//
// CL BLAS
//
// Project Specific Headers
//

#endif // CLALGORITHM_H
