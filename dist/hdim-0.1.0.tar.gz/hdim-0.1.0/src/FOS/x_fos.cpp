//Explicit Instantiation of X_FOS for Wrappers

#include "x_fos.hpp"

template class hdim::X_FOS<float>;
template class hdim::X_FOS<double>;
